//Variaveis
//tipo Nunber 

const meuNumero = 6;
const numeroUm = 10;
const numeroDois = 2;


const soma = numeroDois+ meuNumero
console.log(soma)

const subtracao = numeroUm - meuNumero;
console.log(subtracao);

const multiplicacao = numeroDois * 10;
console.log(multiplicacao);

const divisao = numeroDois / numeroDois;
console.log(divisao)

//Float ( Número decimal )

const numeroTres = 3.3;
const numeroQuatro = .5 // mesma coisa que 0.5

const operacaoM = numeroTres * numeroQuatro
console.log(operacaoM)

//Nam not a Number nao é um numero

 const operacaon = "a" * meuNumero
 console.log(operacao)

//concatenação
 const novaOperacao ="a" + meuNumero
 console.log(novaOperacao)

 // string (texto)  

 const meuNome = "Teotonio"
 const frase = 'Meu nome é: '
 const issoNaoEUmNumero = '50' ;

 const minhaFrase = frase + meuNome;
 console.log(minhaFrase);

 const operacao0 = issoNaoEUmNumero + meuNumero ;
 console.log(novaoperacao)

 //Boolean
 //True ->  verdadeiro;
 //False -> falso;

 const comparacao = 6 === meuNumero;